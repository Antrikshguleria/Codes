#include <iostream>
using namespace std;
#include "poly.cpp"
int main()
{
    poly p1;
    p1.print();
}