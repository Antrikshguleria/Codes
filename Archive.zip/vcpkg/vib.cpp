#include <iostream>
using namespace std;

int main()
{
    int a=3;
    //a++;
    cout<<a++<<endl;
    cout<<++a<<endl;
    int i = 0;
    for(; i < 5;){
        cout << i << " ";
        i++;
    }
    cout << endl;
    cout << i << endl;
    int j = 0;
    for(; j < 5; ){
        cout << j << " ";
        ++j;
    }
    cout << endl;
    cout << j << endl;
}