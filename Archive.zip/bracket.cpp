#include <iostream>
using namespace std;
#include "stack.cpp"
int main()
{
    string s;
    cin >> s;
    stackusingarray<char> s1;
    for (int i = 0; s != "\0"; i++)
    {
        cout << "as" << endl;
    }
}